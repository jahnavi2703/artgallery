package com.klef.jfsd.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.model.Artist;

@Repository
public interface ArtistRepository extends JpaRepository<Artist, Integer>
{
		@Query("select e from Artist e where name=?1 and password=?2")
	   public Artist checkemplogin(String name,String pwd);
}
