package com.klef.jfsd.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public String addcustomer(Customer c) 
	{
		customerRepository.save(c);
		return "Customer Added Successfully";
	}
	
	@Override
	  public Customer checklogin(String username, String pword) {
	    return customerRepository.checklogin(username, pword);
	  }

}
