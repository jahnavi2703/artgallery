package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Artist;
import com.klef.jfsd.springboot.model.Customer;

public interface AdminService 
{
	public List<Artist> viewallartists();
	  public List<Customer> viewallcustomers();
	 // public String deleteartist(int eid);
	 // public Artist viewartistbyid(int eid);
	  public Admin checkadminlogin(String auname,String apwd);
}
