package com.klef.jfsd.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Artist;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.repository.ArtistRepository;
import com.klef.jfsd.springboot.service.AdminService;
import com.klef.jfsd.springboot.service.ArtistService;
import com.klef.jfsd.springboot.service.CustomerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class ClientController 
{
	@Autowired
	   private AdminService adminService;
		
		@Autowired
		private CustomerService customerService;
		
		@Autowired
		private ArtistService artistService;
		
		
		@GetMapping("/")
		public String index()
		{
			return "home";
		}
		
		@GetMapping("login")
		public String login()
		{
			return "loginregistration";
		}
		
		@GetMapping("cushome")
		public String cushome()
		{
			return "Customer/customerhome";
		}
		
		@GetMapping("gallery")
		public String gallery()
		{
			return "Customer/cusgallery";
		}
		
		
		
		
		@PostMapping("addcustomer")
		  public ModelAndView addcustomer(HttpServletRequest request)
		  {
		    ModelAndView mv=new ModelAndView();
		    String msg=null;
		    try {
		      String name=request.getParameter("name");
		      String password=request.getParameter("password");
		      String email=request.getParameter("email");
		      String gender=request.getParameter("gender");
		      String dob=request.getParameter("dob");
		      String contact=request.getParameter("contact");
		      String location=request.getParameter("location");
		      
		      Customer cus=new Customer();
		      cus.setName(name);
		      cus.setPassword(password);
		      cus.setEmail(email);
		      cus.setGender(gender);
		      cus.setDateofbirth(dob);
		      cus.setContact(contact);
		      cus.setLocation(location);
		      //cus.setActive(true);
		      msg=customerService.addcustomer(cus);
		      mv.setViewName("Customer/customerhome");
		      mv.addObject("name",name);
		      
		    }
		    catch(Exception e)
		    {
		      msg="Error occured";
		          mv.setViewName("register");
		        mv.addObject("message",msg);
		    }
		    return mv;
		  }
		
		@PostMapping("checklogin")
		  public ModelAndView checklogin(HttpServletRequest request)
		  {
		    ModelAndView mv=new ModelAndView();
		    
		    String name=request.getParameter("name");
		    String password=request.getParameter("password");
		    
		    Customer cus=customerService.checklogin(name,password);
		    
		    if(cus!=null)
		    {
		      HttpSession session=request.getSession();
		      session.setAttribute("username",name);
		      session.setAttribute("id", cus.getId());
		      session.setAttribute("email", cus.getEmail());
		      mv.setViewName("Customer/customerhome");
		      
		    }
		    else
		    {
		      mv.setViewName("login");
		      mv.addObject("message","Login Failed !..Please Enter correct detials");
		    }
		    return mv;
		  }
		
		@GetMapping("artistl&r")
		public String loginandreg()
		{
			return "Artist/artistl&r";
		}
		
		@PostMapping("requestartist")
		  public ModelAndView addartist(HttpServletRequest request)
		  {
		    ModelAndView mv=new ModelAndView();
		    String msg=null;
		    try {
		      String name=request.getParameter("name");
		      String password=request.getParameter("password");
		      String email=request.getParameter("email");
		      String gender=request.getParameter("gender");
		      String dob=request.getParameter("dob");
		      String contact=request.getParameter("contact");
		      String location=request.getParameter("location");
		      String about =request.getParameter("about");
		      
		      Artist a=new Artist();
		      a.setName(name);
		      a.setPassword(password);
		      a.setContact(contact);
		      a.setDateofbirth(dob);
		      a.setEmail(email);
		      a.setLocation(location);
		      a.setAbout(about);
		      a.setGender(gender);
		      a.setActive(false);
		      
		      
		      
		      msg=artistService.addartist(a);
		      mv.setViewName("Artist/artistl&r");
		      mv.addObject("name",name);
		      
		    }
		    catch(Exception e)
		    {
		      msg="Error occured";
		          mv.setViewName("errorpage");
		        mv.addObject("message",msg);
		    }
		    return mv;
		  }
		
		
		@PostMapping("checkartist")
		  public ModelAndView checkartist(HttpServletRequest request)
		  {
		    ModelAndView mv=new ModelAndView();
		    
		    String name=request.getParameter("name");
		    String password=request.getParameter("password");
		    
		    
		    Artist aa;
		    
		    Artist a=artistService.checklogin(name, password);
		    
		    if(a!=null)
		    {
		      if(a.isActive()==true)
		      {
		      HttpSession session=request.getSession();
		      session.setAttribute("username",name);
		      session.setAttribute("id", a.getId());
		      session.setAttribute("email", a.getEmail());
		      mv.setViewName("Artist/artisthome");
		      }
		      else
		      {
		    	  String msg="Still in activation";
		    	  mv.setViewName("Artist/artistl&r");
		    	  mv.addObject("msg",msg);
		      }
		    }
		    else
		    {
		      mv.setViewName("Artist/artistl&r");
		      mv.addObject("msg","Login Failed !..Please Enter correct detials");
		    }
		    return mv;
		  }
		
		
		@GetMapping("adminlogin")
		public String adminlogin()
		{
			return "Admin/adminlogin";
		}
		
		@PostMapping("checkadminlogin")
		  public ModelAndView checkadminlogin(HttpServletRequest request)
		  {
		    ModelAndView mv=new ModelAndView();
		    
		    String name=request.getParameter("name");
		    String password=request.getParameter("password");
		    
		    Admin a=adminService.checkadminlogin(name, password);
		    
		    if(a!=null)
		    {
		      HttpSession session=request.getSession();
		      session.setAttribute("username",name);
		      session.setAttribute("id", a.getId());
		      mv.setViewName("Admin/adminhome");
		      
		    }
		    else
		    {
		      mv.setViewName("Admin/adminlogin");
		      mv.addObject("message","Login Failed !..Please Enter correct detials");
		    }
		    return mv;
		  }
		
		
}
