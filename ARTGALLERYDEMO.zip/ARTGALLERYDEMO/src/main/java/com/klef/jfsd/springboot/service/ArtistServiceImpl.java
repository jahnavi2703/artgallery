package com.klef.jfsd.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Artist;
import com.klef.jfsd.springboot.repository.ArtistRepository;

@Service
public class ArtistServiceImpl implements ArtistService
{
	@Autowired
	private ArtistRepository artistRepository;
	
	
	@Override
	public String addartist(Artist a)
	{
		artistRepository.save(a);
		return "Artist Added Successfully";
	}


	@Override
	public Artist checklogin(String name, String pword) {
		
		return artistRepository.checkemplogin(name, pword);
	}
}
