package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Artist;
import com.klef.jfsd.springboot.model.Customer;

public interface ArtistService 
{
	 public String addartist(Artist a);
	 public Artist checklogin(String name,String pword);
	 
}
