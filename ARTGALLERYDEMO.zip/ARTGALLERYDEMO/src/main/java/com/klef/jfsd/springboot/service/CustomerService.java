package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Customer;

public interface CustomerService 
{
	public String addcustomer(Customer c);
	public Customer checklogin(String username,String pword);
}
